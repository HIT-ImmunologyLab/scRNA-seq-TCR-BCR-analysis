Downloaded from https://github.com/christianbach/tablesorter

See http://tablesorter.com/docs/ for license information
